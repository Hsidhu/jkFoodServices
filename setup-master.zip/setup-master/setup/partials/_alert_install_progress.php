<div class="card-body text-center p-4 install-progress">
    <div class="mt-4">
        <i
            class="spinner-border spinner-border-lg text-muted"
            style="width: 6rem; height: 6rem;border-width: .2em;"
            role="status"
        ></i>
    </div>
    <h3 class="my-4">Setting up your application...&nbsp;&nbsp;&#127858;</h3>
    <p class="message"></p>
</div>
